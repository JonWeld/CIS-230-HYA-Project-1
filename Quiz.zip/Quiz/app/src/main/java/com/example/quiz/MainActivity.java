package com.example.quiz;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView questionTextView;
    private RadioGroup optionsRadioGroup;
    private RadioButton option1RadioButton, option2RadioButton, option3RadioButton, option4RadioButton;
    private Button submitButton;
    private Button restartButton;

    private String[] questions = {
            "Question 1: When was Nintendo founded?",
            "Question 2: What is the most popular brand of soda?",
            "Question 3: Who is the main character of the show, Breaking Bad?",
            "Question 4: What metal is the statue of liberty made of?",
            "Question 5: What programming language was the game, Minecraft, originally written in?",
            "Question 6: What Star Wars movie has the highest rating?",
            "Question 7: What is the capital of Italy?",
            "Question 8: What song is referred to as a \"Rick-Roll\" by the internet?",
            "Question 9: Who was the first superhero introduced in DC comic books?",
            "Question 10: What is the name of the hammer Thor wields?"
    };

    private String[][] options = {
            {"1880", "1889", "1901", "1910"},
            {"Coca-Cola", "Pepsi", "Mountain Dew", "Dr. Pepper"},
            {"Rick Grimes", "Jesse Pinkman", "Saul Goodman", "Walter White"},
            {"Bronze", "Copper", "Lead", "Titanium"},
            {"C++", "Javascript", "Java", "Ruby"},
            {"The Revenge of the Sith", "The Force Awakens", "A New Hope", "The Empire Strikes Back"},
            {"Istanbul", "Rome", "Paris", "London"},
            {"Never Gonna Give You Up - Rick Astley", "Jesse's Girl - Rick Springfield", "Super Freak - Rick James", "Livin' La Vida Loca - Ricky Martin"},
            {"Batman", "Green Lantern", "Martian Man-Hunter", "Superman"},
            {"Odin", "Ragnarok", "Mjolnir", "Jonathan"}
    };

    private int[] correctAnswers = {1, 0, 3, 1, 2, 3, 1, 0, 3, 2};
    private int currentQuestion = 0;
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionTextView = findViewById(R.id.questionTextView);
        optionsRadioGroup = findViewById(R.id.optionsRadioGroup);
        option1RadioButton = findViewById(R.id.option1RadioButton);
        option2RadioButton = findViewById(R.id.option2RadioButton);
        option3RadioButton = findViewById(R.id.option3RadioButton);
        option4RadioButton = findViewById(R.id.option4RadioButton);
        submitButton = findViewById(R.id.submitButton);
        restartButton = findViewById(R.id.restartButton);

        displayQuestion();

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });

        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restartQuiz();
            }
        });
    }

    private void displayQuestion() {
        questionTextView.setText(questions[currentQuestion]);
        option1RadioButton.setText(options[currentQuestion][0]);
        option2RadioButton.setText(options[currentQuestion][1]);
        option3RadioButton.setText(options[currentQuestion][2]);
        option4RadioButton.setText(options[currentQuestion][3]);
        optionsRadioGroup.clearCheck();
    }

    private void checkAnswer() {
        int selectedOption = optionsRadioGroup.getCheckedRadioButtonId();
        if (selectedOption == -1) {
            Toast.makeText(this, "Please select an option", Toast.LENGTH_SHORT).show();
        } else {
            RadioButton selectedRadioButton = findViewById(selectedOption);
            int selectedAnswer = optionsRadioGroup.indexOfChild(selectedRadioButton);

            if (selectedAnswer == correctAnswers[currentQuestion]) {
                score++;
            }

            currentQuestion++;

            if (currentQuestion < questions.length) {
                displayQuestion();
            } else {
                showScore();
            }
        }
    }

    private void showScore() {
        String scoreMessage = "Quiz completed!\nYour score: " + score + "/" + questions.length;
        Toast.makeText(this, scoreMessage, Toast.LENGTH_LONG).show();

        submitButton.setEnabled(false);
        restartButton.setVisibility(View.VISIBLE);
    }

    private void restartQuiz() {
        currentQuestion = 0;
        score = 0;
        displayQuestion();
        submitButton.setEnabled(true);
        restartButton.setVisibility(View.GONE);
    }
}

